sap.ui.define(
    [
        'sap/fe/core/PageController',
        "sap/m/Dialog",
        'sap/m/MessageToast',
        "sap/m/MessageBox",
    ],
    function (PageController, Dialog, MessageToast, MessageBox) {
        'use strict';

        var oController;
        var dataOrderTable;
        var dataMasterTable;

        return PageController.extend('productioncockpitapp.ext.main.Main', {
            /**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             * @memberOf productioncockpitapp.ext.main.Main
             */
            onInit: function () {
                //      PageController.prototype.onInit.apply(this, arguments); // needs to be called to properly initialize the page controller
                this.byId("IconTabFilterId").setSelectedKey("combined");
                oController = this;
                //      PageController.prototype.onInit.apply(this, arguments); // needs to be called to properly initialize the page controller
                this.byId("IconTabFilterId").setSelectedKey("combined");
                this.byId("TableMaster").attachSelectionChange(function (oEvent) {
                    if (oEvent.getParameters().selectedContext.length > 0) {
                        /* oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableMaster-content::CustomAction::componentsAction").setEnabled(true); */
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableMaster-content::CustomAction::operationsAction").setEnabled(true);
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableMaster-content::CustomAction::kittingAction").setEnabled(true);                        
                        //Modifica MDB - gestione abilitazione action ROL in base a selezione e a valore OrderPersonalization - 02/02/2026 - INIZIO
                        /* if (oEvent.getParameters().selectedContext.length > 1) {
                            oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableMaster-content::CustomAction::rolAction").setEnabled(false);
                        } else {
                            oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableMaster-content::CustomAction::rolAction")
                                .setEnabled(oEvent.getParameters().selectedContext[0].getObject().OrderPersonalization !== "");
                        } */
                        //Modifica MDB - gestione abilitazione action ROL in base a selezione e a valore OrderPersonalization - 02/02/2026 - FINE
                    } else {
                        /* oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableMaster-content::CustomAction::componentsAction").setEnabled(false); */
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableMaster-content::CustomAction::operationsAction").setEnabled(false);
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableMaster-content::CustomAction::kittingAction").setEnabled(false);
                        /* oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableMaster-content::CustomAction::rolAction").setEnabled(false); */
                    }
                });
                this.byId("TableCombined").attachSelectionChange(function (oEvent) {
                    if (oEvent.getParameters().selectedContext.length > 0) {
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::releaseOrderAction").setEnabled(true);
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::technicalCompleteOrderAction").setEnabled(true);
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::closeOrderAction").setEnabled(true);
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::componentsCombinedAction").setEnabled(true);
                        /* oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::operationsCombinedAction").setEnabled(true); */
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::kittingCombinedAction").setEnabled(true);
                        /* oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::creaOrdineAction").setEnabled(true); */
                    } else {
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::releaseOrderAction").setEnabled(false);
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::technicalCompleteOrderAction").setEnabled(false);
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::closeOrderAction").setEnabled(false);
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::componentsCombinedAction").setEnabled(false);
                       /*  oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::operationsCombinedAction").setEnabled(false); */
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::kittingCombinedAction").setEnabled(false);
                        /* oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content::CustomAction::creaOrdineAction").setEnabled(false); */
                    }
                });
                /*this.byId("Table").attachSelectionChange(function (oEvent) {
                    if (oEvent.getParameters().selectedContext.length > 0) {
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--Table-content::CustomAction::componentsOrderAction").setEnabled(true);
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--Table-content::CustomAction::operationsOrderAction").setEnabled(true);
                    } else {
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--Table-content::CustomAction::componentsOrderAction").setEnabled(false);
                        oController.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--Table-content::CustomAction::operationsOrderAction").setEnabled(false);
                    }
                });*/
                //this.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--Table-content").setSelectionMode("Multi")
                //this.byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content").setSelectionMode("Multi")
            },

            /**
             * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
             * (NOT before the first rendering! onInit() is used for that one!).
             * @memberOf productioncockpitapp.ext.main.Main
             */
            //  onBeforeRendering: function() {
            //
            //  },

            /**
             * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
             * This hook is the same one that SAPUI5 controls get after being rendered.
             * @memberOf productioncockpitapp.ext.main.Main
             */
            onAfterRendering: function () {
                //sap.ui.getCore().byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--FilterBarMaster-content-btnSearch").firePress()
                // recupero dati tabella ordini
                /*        var oTable = this.byId("Table");
                       var oBinding = oTable.getRowBinding()
                       oBinding.requestContexts(0, 10000).then(function(aContexts) {
                           dataOrderTable = aContexts.map(ctx => ctx.getObject());
                           console.log("Order Table length "+dataOrderTable.length)
                       }); */
                // recupero dati tabella master ordini
                /*    var oTableMaster = this.byId("TableMaster");
                   var oBinding1 = oTableMaster.getRowBinding()
                   oBinding1.requestContexts(0, 10000).then(function (aContexts) {
                       dataMasterTable = aContexts.map(ctx => ctx.getObject());
                       console.log("Master Table length " + dataMasterTable.length)
                   }); */
            },

            /**
             * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
             * @memberOf productioncockpitapp.ext.main.Main
             */
            //  onExit: function() {
            //
            //  }

            customFilterSearch: function (oEvent) {
                var oTable = this.byId("TableMaster"); // ID della tabella
                var oBinding = oTable.getRowBinding(); // oTable.getBinding("rows") per Grid/Table classiche
                var filterArray = []

                // Costruisci i filtri (in base al tuo scenario)
                setTimeout(() => {
                    oBinding.filter([]);
                    if (this.byId("FilterBarMaster").getFilters().filters.length > 0) {
                        if (this.byId("FilterBarMaster").getFilters().filters[0].aFilters === undefined || this.byId("FilterBarMaster").getFilters().filters[0].aFilters === null) {
                            for (var i = 0; i < this.byId("FilterBarMaster").getFilters().filters.length; i++) {
                                var oFilter = new sap.ui.model.Filter(this.byId("FilterBarMaster").getFilters().filters[i].sPath, this.byId("FilterBarMaster").getFilters().filters[i].sOperator, this.byId("FilterBarMaster").getFilters().filters[i].oValue1);
                                filterArray.push(oFilter)
                                // Applica il filtro
                                if (oBinding) {
                                    oBinding.filter(filterArray);
                                }
                            }
                        } else {
                            for (var i = 0; i < this.byId("FilterBarMaster").getFilters().filters[0].aFilters.length; i++) {
                                var oFilter = new sap.ui.model.Filter(this.byId("FilterBarMaster").getFilters().filters[0].aFilters[i].sPath, this.byId("FilterBarMaster").getFilters().filters[0].aFilters[i].sOperator, this.byId("FilterBarMaster").getFilters().filters[0].aFilters[i].oValue1);
                                filterArray.push(oFilter)
                            }
                            // Applica il filtro
                            if (oBinding) {
                                oBinding.filter(filterArray);
                            }
                        }
                    } else {
                        oBinding.filter([]);
                    }
                }, 100);

            },

            selectIconTabFilter: function (oEvent) {
                if (oEvent.getSource().getSelectedKey() === "order") {
                    // Ottieni la tabella
                    var oTable = this.byId("Table"); // ID della tabella
                    var oBinding = oTable.getRowBinding(); // oTable.getBinding("rows") per Grid/Table classiche
                    var filterArray = []

                    // Costruisci i filtri (in base al tuo scenario)
                    if (this.byId("FilterBarMaster").getFilters().filters.length > 0) {
                        for (var i = 0; i < this.byId("FilterBarMaster").getFilters().filters.length; i++) {
                            var oFilter = new sap.ui.model.Filter(this.byId("FilterBarMaster").getFilters().filters[i].sPath, sap.ui.model.FilterOperator.EQ, this.byId("FilterBarMaster").getFilters().filters[i].oValue1);
                            if (oFilter.sPath === 'CombinedOrder') {
                                oFilter.sPath = 'CprodOrd'
                            }
                            filterArray.push(oFilter)
                            // Applica il filtro
                            if (oBinding) {
                                oBinding.filter(filterArray);
                            }
                        }
                    } else {
                        oBinding.filter([]);
                    }

                } else if (oEvent.getSource().getSelectedKey() === "combined") {
                    var oTable = this.byId("TableCombined"); // ID della tabella
                    var oBinding = oTable.getRowBinding(); // oTable.getBinding("rows") per Grid/Table classiche
                    var filterArray = []

                    // Costruisci i filtri (in base al tuo scenario)
                    if (this.byId("FilterBarMaster").getFilters().filters.length > 0) {
                        for (var i = 0; i < this.byId("FilterBarMaster").getFilters().filters.length; i++) {
                            if (this.byId("FilterBarMaster").getFilters().filters[i].sPath === 'MasterProductionOrder' || this.byId("FilterBarMaster").getFilters().filters[0].aFilters !== undefined) {
                                if (this.byId("TableMaster").getMDCTable().getRowBinding() !== undefined) {
                                    // modifica DL - 22/12/2025 - gestione ordini multipli
                                    if (this.byId("FilterBarMaster").getFilters().filters[0].aFilters === undefined) {
                                        var value = this.byId("TableMaster").getMDCTable().getRowBinding().aContexts[0].getValue().CombinedOrder
                                        var oFilter = new sap.ui.model.Filter("CombinedOrder", sap.ui.model.FilterOperator.EQ, value);
                                        filterArray.push(oFilter)
                                    } else {
                                        for (var y = 0; y < this.byId("TableMaster").getMDCTable().getRowBinding().aContexts.length; y++) {
                                            filterArray.push(new sap.ui.model.Filter("CombinedOrder", sap.ui.model.FilterOperator.EQ, this.byId("TableMaster").getMDCTable().getRowBinding().aContexts[y].getValue().CombinedOrder))
                                        }
                                    }
                                }
                            } else {
                                var oFilter = new sap.ui.model.Filter(this.byId("FilterBarMaster").getFilters().filters[i].sPath, sap.ui.model.FilterOperator.EQ, this.byId("FilterBarMaster").getFilters().filters[i].oValue1);
                                filterArray.push(oFilter)
                            }
                            if (oBinding) {
                                oBinding.filter(filterArray);
                            }
                        }
                    } else {
                        oBinding.filter([]);
                    }
                    // modifica DL - 21/01/2025 - valorizzo anche la tabella degli ordini
                    /*var oTable = this.byId("Table"); // ID della tabella
                    var oBinding = oTable.getRowBinding(); // oTable.getBinding("rows") per Grid/Table classiche
                    var filterArray = []

                    // Costruisci i filtri (in base al tuo scenario)
                    if (this.byId("FilterBarMaster").getFilters().filters.length > 0) {
                        for (var i = 0; i < this.byId("FilterBarMaster").getFilters().filters.length; i++) {
                            var oFilter = new sap.ui.model.Filter(this.byId("FilterBarMaster").getFilters().filters[i].sPath, sap.ui.model.FilterOperator.EQ, this.byId("FilterBarMaster").getFilters().filters[i].oValue1);
                            if (oFilter.sPath === 'CombinedOrder') {
                                oFilter.sPath = 'CprodOrd'
                            }
                            filterArray.push(oFilter)
                            // Applica il filtro
                            if (oBinding) {
                                oBinding.filter(filterArray);
                            }
                        }
                    } else {
                        oBinding.filter([]);
                    }*/
                    // modifica DL - 21/01/2025 - valorizzo anche la tabella degli ordini - FINE
                }
                /// OLD
                /*if(oEvent.getSource().getSelectedKey() === 'master'){
                    this.byId("FilterBarMaster").setVisible(true);
                    this.byId("FilterBarCombined").setVisible(false);
                } else if(oEvent.getSource().getSelectedKey() === 'combined') {
                    this.byId("FilterBarMaster").setVisible(false);
                    this.byId("FilterBarCombined").setVisible(true);
                }*/
            },

            onNavigateToComponentsMasterOrder: function (oEvent) {

                const oComponent = this.getOwnerComponent().getExtensionComponent();

                this.oRouter = oComponent.getRouter();

                var key = ""
                for (var i = 0; i < this.byId("TableMaster").getSelectedContexts().length; i++) {
                    if (i === 0) {
                        key = this.byId("TableMaster").getSelectedContexts()[i].getObject().ID
                    } else {
                        key = key + ";" + this.byId("TableMaster").getSelectedContexts()[i].getObject().ID
                    }
                }

                this.oRouter.navTo("ZZ1_C_MASTERORDER_COMPComponentsPage", {
                    ZZ1_C_MASTERORDER_COMPKey: "'" + key + "'", "?query": {
                        //layout: "ThreeColumnsMidExpanded"
                    }
                });


            },

            onNavigateToOperationsCombinedOrder: function (oEvent) {
                const oComponent = this.getOwnerComponent().getExtensionComponent();

                this.oRouter = oComponent.getRouter();

                var key = ""
                for (var i = 0; i < this.byId("TableCombined").getSelectedContexts().length; i++) {
                    if (i === 0) {
                        key = this.byId("TableCombined").getSelectedContexts()[i].getObject().ID
                    } else {
                        key = key + ";" + this.byId("TableCombined").getSelectedContexts()[i].getObject().ID
                    }
                }

                this.oRouter.navTo("ZZ1_C_COMBINEDORDER_OPEROperationsPage", {
                    ZZ1_C_COMBINEDORDER_OPERKey: "'" + key + "'", "?query": {
                        //layout: "ThreeColumnsMidExpanded"
                    }
                });
            },

            onNavigateToComponentsCombinedOrder: function (oEvent) {

                const oComponent = this.getOwnerComponent().getExtensionComponent();

                this.oRouter = oComponent.getRouter();

                var key = ""
                for (var i = 0; i < this.byId("TableCombined").getSelectedContexts().length; i++) {
                    if (i === 0) {
                        key = this.byId("TableCombined").getSelectedContexts()[i].getObject().ID
                    } else {
                        key = key + ";" + this.byId("TableCombined").getSelectedContexts()[i].getObject().ID
                    }
                }

                this.oRouter.navTo("ZZ1_C_COMBINEDORDER_COMPComponentsPage", {
                    ZZ1_C_COMBINEDORDER_COMPKey: "'" + key + "'", "?query": {
                        //layout: "ThreeColumnsMidExpanded"
                    }
                });


            },

            onNavigateToOperationsMasterOrder: function (oEvent) {
                const oComponent = this.getOwnerComponent().getExtensionComponent();

                this.oRouter = oComponent.getRouter();

                var key = ""
                for (var i = 0; i < this.byId("TableMaster").getSelectedContexts().length; i++) {
                    if (i === 0) {
                        key = this.byId("TableMaster").getSelectedContexts()[i].getObject().ID
                    } else {
                        key = key + ";" + this.byId("TableMaster").getSelectedContexts()[i].getObject().ID
                    }
                }

                this.oRouter.navTo("ZZ1_C_MASTERORDER_OPEROperationsPage", {
                    ZZ1_C_MASTERORDER_OPERKey: "'" + key + "'", "?query": {
                        //layout: "ThreeColumnsMidExpanded"
                    }
                });
            },

            onNavigateToComponentsOrder: function (oEvent) {

                const oComponent = this.getOwnerComponent().getExtensionComponent();

                this.oRouter = oComponent.getRouter();

                var key = ""
                for (var i = 0; i < this.byId("Table").getSelectedContexts().length; i++) {
                    if (i === 0) {
                        key = this.byId("Table").getSelectedContexts()[i].getObject().ID
                    } else {
                        key = key + ";" + this.byId("Table").getSelectedContexts()[i].getObject().ID
                    }
                }

                this.oRouter.navTo("ZZ1_C_MFG_OrderComponentsPage", {
                    ZZ1_C_MFG_OrderCompKey: "'" + key + "'", "?query": {
                        //layout: "ThreeColumnsMidExpanded"
                    }
                });


            },

            onNavigateToOperationsOrder: function (oEvent) {
                const oComponent = this.getOwnerComponent().getExtensionComponent();

                this.oRouter = oComponent.getRouter();

                var key = ""
                for (var i = 0; i < this.byId("Table").getSelectedContexts().length; i++) {
                    if (i === 0) {
                        key = this.byId("Table").getSelectedContexts()[i].getObject().ID
                    } else {
                        key = key + ";" + this.byId("Table").getSelectedContexts()[i].getObject().ID
                    }
                }

                this.oRouter.navTo("ZZ1_C_MFG_OrderOperationsPage", {
                    ZZ1_C_MFG_OrderOperKey: "'" + key + "'", "?query": {

                    }
                });
            },

            onNavigateToKittingMasterOrder: function (oEvent) {

                const oComponent = this.getOwnerComponent().getExtensionComponent();

                this.oRouter = oComponent.getRouter();

                var key = ""
                for (var i = 0; i < this.byId("TableMaster").getSelectedContexts().length; i++) {
                    if (i === 0) {
                        key = this.byId("TableMaster").getSelectedContexts()[i].getObject().ID
                    } else {
                        key = key + ";" + this.byId("TableMaster").getSelectedContexts()[i].getObject().ID
                    }
                }

                this.oRouter.navTo("ZZ1_C_MASTERORDER_COMPKittingPage", {
                    ZZ1_C_MASTERORDER_KITTINGKey: "'" + key + "'", "?query": {
                        //layout: "ThreeColumnsMidExpanded"
                    }
                });


            },

            onNavigateToKittingCombinedOrder: function (oEvent) {

                const oComponent = this.getOwnerComponent().getExtensionComponent();

                this.oRouter = oComponent.getRouter();

                var key = ""
                for (var i = 0; i < this.byId("TableCombined").getSelectedContexts().length; i++) {
                    if (i === 0) {
                        key = this.byId("TableCombined").getSelectedContexts()[i].getObject().ID
                    } else {
                        key = key + ";" + this.byId("TableCombined").getSelectedContexts()[i].getObject().ID
                    }
                }

                this.oRouter.navTo("ZZ1_C_COMBINEDORDER_COMPKittingPage", {
                    ZZ1_C_COMBINEDORDER_KITTINGKey: "'" + key + "'", "?query": {
                        //layout: "ThreeColumnsMidExpanded"
                    }
                });


            },

            onCallServiceROL: function (oEvent) {
                //Modifica MDB - recupero OrderPersonalization per action GetOrderDetails - 02/02/2026 - INIZIO
                const selectedItemContext = this.byId("TableMaster").getSelectedContexts();
                if (selectedItemContext.length > 1) {
                    MessageToast.show(oController.getResourceBundle().getText("selectOnlyOneRecord"))
                    return;
                }
                const selectedItem = selectedItemContext[0].getObject();
                const oidOrdine = selectedItem.OrderPersonalization;
                //Modifica MDB - recupero OrderPersonalization per action GetOrderDetails - 02/02/2026 - FINE
                const oModel = oController.getView().getModel();
                var oBindingContext = oModel.bindContext("/GetOrderDetails(...)");

                oBindingContext.setParameter("oidOrdine",
                    oidOrdine
                );

                var oBusyDialog = new sap.m.BusyDialog();
                oBusyDialog.open();
                oBindingContext.execute().then((oResult) => {
                    var oContext = oBindingContext.getBoundContext();
                    var oResult = oContext.getObject().value;
                    oBusyDialog.close();
                    if (oResult.serviceStatus.description.indexOf("OK") > -1) {
                        // apro popup in cui mostro risultati della chiamata del servizio
                        if (oController.pROLDialog === null || oController.pROLDialog === undefined) {
                            oController.pROLDialog = sap.ui.xmlfragment(this.getView().getId(), "productioncockpitapp.ext.Fragment.ROL", oController);
                            oController.getView().addDependent(oController.pROLDialog);
                        }
                        //Modifica MDB - setto modello con il risultato della chiamata - 02/02/2026 - INIZIO 
                        const oModel = new sap.ui.model.json.JSONModel({
                            numeroOrdineROL: oResult.numeroOrdineROL,
                            articoloCod: oResult.articoloCod,
                            coloreCod: oResult.coloreCod,
                            taglia: oResult.taglia,
                            numeroPezzi: oResult.numeroPezzi,
                            tessuto: oResult.tessuto
                        });
                        //Modifica MDB - setto modello con il risultato della chiamata - 02/02/2026 - FINE
                        oController.getView().setModel(oModel, "order");

                        oController.pROLDialog.open()
                    } else {
                        MessageBox.error(oResult.numeroOrdineROL + " : " + oResult.serviceStatus.description);
                        oResult.serviceStatus.description
                    }

                }).catch((oError) => {
                    oBusyDialog.close();
                    // TODO - gestione errore
                    if (oError.error === undefined || oError.error === null) {
                        oController.openDialogMessageText(oError, "E");
                    } else {
                        oController.openDialogMessageText(oError.error.message, "E");
                    }
                    return
                });
            },

            onShowDialog: function () {

            },

            onCloseOrder: async function (oEvent) {
                oController.action = oEvent.getParameters().id.split("::")[oEvent.getParameters().id.split("::").length - 1]
                const that = this;
                const procede = async function () {
                    var found = false
                    var tableCombined = oController.byId("TableCombined")
                    if (oController.byId("TableCombined").getSelectedContexts().length === 1) {
                        // cerco se esiste almeno un componente con ricarica stock
                        var oModel = oController.getView().getModel(); // OData V4 Model
                        var oListBinding = oModel.bindList("/ZZ1_PRODUCTION_COCKPIT_API('" + oController.byId("TableCombined").getSelectedContexts()[0].getObject().ID + "')/to_ZZ1_C_COMBORDER_COMP");
                        oController.oBusyDialog = new sap.m.BusyDialog();
                        oController.oBusyDialog.open();

                        oListBinding.requestContexts().then(async aContexts => {
                            oController.oBusyDialog.close();

                            console.log("Dati letti:", aContexts.map(oContext => oContext.getObject()));

                            var dataProductionOrder = await oController.getProductionOrder()

                            var oBusyDialog = new sap.m.BusyDialog();
                            oBusyDialog.open();
                            const oModel = oController.getView().getModel();
                            var oBindingContext = oModel.bindContext("/CloseOrder(...)");

                            oBindingContext.setParameter("OrderID", dataProductionOrder);

                            oBindingContext.execute().then((oResult) => {
                                var oContext = oBindingContext.getBoundContext();

                                var message = ""
                                var value = oContext.getObject().value;
                                var messageArray = value.split("|");

                                if (!value || value.trim() === "") {
                                    message = value
                                    oController.openDialogMessageText(message, "E");
                                } else {
                                    if (oContext.getObject().value.indexOf("Error") > -1) {
                                        sap.m.MessageBox.error(
                                            oController.getResourceBundle().getText("followingErrorsFound") + "\n\n" +
                                            messageArray.join("\n"),
                                            {
                                                title: oController.getResourceBundle().getText("errors")
                                            }
                                        );
                                    } else {
                                        var data = []
                                        found = false
                                        var objectCopy = {}

                                        for (var i = 0; i < aContexts.map(oContext => oContext.getObject()).length; i++) {
                                            objectCopy = {}
                                            if (aContexts.map(oContext => oContext.getObject())[i].requirementtype !== 'BB') {

                                            } else {
                                                found = true
                                                objectCopy = aContexts.map(oContext => oContext.getObject())[i]
                                                objectCopy.selectedCheckboxRecharge = true
                                                objectCopy.editableCheckboxRecharge = true
                                                data.push(objectCopy)
                                            }
                                        }

                                        if (found) {
                                            // apro popup con componenti che hanno flag di ricarica stock
                                            if (oController.pComponentsToClosing === null || oController.pComponentsToClosing === undefined) {
                                                oController.pComponentsToClosing = sap.ui.xmlfragment(oController.getView().getId(), "productioncockpitapp.ext.Fragment.ComponentsToClosing", oController);
                                                oController.getView().addDependent(oController.pComponentsToClosing);
                                            }
                                            const oModel = new sap.ui.model.json.JSONModel(data);
                                            oController.getView().setModel(oModel, "SelectedComponentsToClosing");
                                            oController.pComponentsToClosing.open()
                                            oBusyDialog.close();
                                            return;
                                        }
                                    }
                                }
                                //refresh tabella Combined
                                if (tableCombined && tableCombined.getMDCTable().clearSelection) {
                                    tableCombined.getMDCTable().clearSelection();
                                }
                                sap.ui.getCore().byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content-innerTable").getBinding("rows").refresh()
                                oBusyDialog.close();
                            }).catch((oError) => {
                                oBusyDialog.close();
                                if (oError.error !== undefined && oError.error !== null) {
                                    oController.openDialogMessageText(oError.error.message, "E");
                                } else {
                                    oController.openDialogMessageText(oError, "E");
                                }
                            });

                        }).catch(err => {
                            oController.oBusyDialog.close();
                            console.log("Errore nella chiamata OData:", err);
                        });
                    } else {
                        MessageToast.show(oController.getResourceBundle().getText("selectOnlyOneRecord"))
                    }
                    /*var dataProductionOrder = oController.getProductionOrder()
                    //alert(JSON.stringify(dataProductionOrder))
    
                    var oBusyDialog = new sap.m.BusyDialog();
                    oBusyDialog.open();
                    const oModel = oController.getView().getModel();
                    var oBindingContext = oModel.bindContext("/CloseOrder(...)");
    
                    oBindingContext.setParameter("OrderID",
                        dataProductionOrder //'1234567'
                    );
    
                    oBindingContext.execute().then((oResult) => {
                        var oContext = oBindingContext.getBoundContext();
    
                        var message = ""
                        var messageArray = oContext.getObject().value.split("|")
                        if (messageArray.length === 0) {
                            message = oContext.getObject().value
                            oController.openDialogMessageText(message, "E");
                        } else {
                            if (oContext.getObject().value.indexOf("Error") > -1) {
                                sap.m.MessageBox.error(
                                    oController.getResourceBundle().getText("followingErrorsFound") + "\n\n" +
                                    messageArray.join("\n"),
                                    {
                                        title: oController.getResourceBundle().getText("errors")
                                    }
                                );
                            } else {
                                sap.m.MessageBox.success(
                                    messageArray.join("\n"),
                                    {
                                        title: oController.getResourceBundle().getText("success")
                                    }
                                );
                            }
                        }
                        oBusyDialog.close();
                    }).catch((oError) => {
                        oBusyDialog.close();
                        if (oError.error !== undefined && oError.error !== null) {
                            oController.openDialogMessageText(oError.error.message, "E");
                        } else {
                            oController.openDialogMessageText(oError, "E");
                        }
                    });*/
                };

                sap.m.MessageBox.confirm(
                    "Sei sicuro di voler eliminare?",
                    {
                        title: "Conferma",
                        actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
                        emphasizedAction: sap.m.MessageBox.Action.OK,
                        onClose: async function (oAction) {
                            if (oAction === sap.m.MessageBox.Action.OK) {
                                await procede();
                            } else {
                                return;
                            }
                        }
                    }
                );

            },

            onConfirmComponentsToClosingDialogDialog: function (oEvent) {
                console.log("onConfirmComponentsToClosingDialogDialog");
                var tableCombined = oController.byId("TableCombined");
                var dataToSend = []
                var dataObjectToSend = {}
                var table = this.getView()
                    .getModel("SelectedComponentsToClosing")
                    .getProperty("/") || [];

                table = table.filter(function (item) {
                    return item.selectedCheckboxRecharge;
                });

                for (var i = 0; i < table.length; i++) {
                    dataObjectToSend = {}
                    dataObjectToSend.id = "001"
                    dataObjectToSend.CprodOrd = table[i].CprodOrd
                    dataObjectToSend.FshMprodOrd = table[i].FshMprodOrd
                    dataObjectToSend.matnr_new = ""
                    dataObjectToSend.matnr_old = table[i].Material
                    dataObjectToSend.charg = table[i].Batch
                    dataObjectToSend.meins = table[i].BaseUnit
                    dataObjectToSend.menge = Number(table[i].TotalQuantityInEntryUnit)
                    dataObjectToSend.vornr = table[i].ManufacturingOrderOperation
                    dataObjectToSend.plnfl = table[i].ManufacturingOrderSequence
                    dataObjectToSend.note = ""
                    dataObjectToSend.reason = ""
                    dataObjectToSend.lgort = table[i].Lgort1
                    dataObjectToSend.werks = table[i].Plant
                    dataObjectToSend.stk_seg = table[i].RequirementSegment
                    dataObjectToSend.action = "CHIU"

                    dataToSend.push(dataObjectToSend)
                }

                var oBusyDialog = new sap.m.BusyDialog();
                oBusyDialog.open();

                const oModel = oController.getView().getModel();
                var oBindingContext = oModel.bindContext("/Replacement(...)");
                oBindingContext.setParameter("Record",
                    dataToSend
                );

                if (dataToSend.length > 0) {
                    oBindingContext.execute().then(async (oResult) => {
                        oBusyDialog.close();
                        var oContext = oBindingContext.getBoundContext();
                        //oController.openDialogMessageText(oController.getResourceBundle().getText("operationCompletedSuccefully"), "S");
                        var v = oContext.getObject().value;
                        var s = (typeof v === "string") ? v : JSON.stringify(v ?? "");

                        if (/* oContext.getObject().value.indexOf("Error") > -1 */s.includes("Error")) {
                            oController.openDialogMessageText(oContext.getObject().value, "E");
                        } else {
                            //oController.openDialogMessageText(oContext.getObject().value, "S");
                            oController.openDialogMessageText(oController.getResourceBundle().getText("operationCompletedSuccefully"), "S");
                        }
                        //oController.openDialogMessageText(oController.getResourceBundle().getText("operationCompletedSuccefully"), "S");
                        //alert("chiamo CLOSE action")
                        //refresh tabella Combined
                        if (tableCombined && tableCombined.getMDCTable().clearSelection) {
                            tableCombined.getMDCTable().clearSelection();
                        }
                        sap.ui.getCore().byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content-innerTable").getBinding("rows").refresh()
                    }).catch((oError) => {
                        oBusyDialog.close();
                        if (oError.error !== undefined && oError.error !== null) {
                            oController.openDialogMessageText(oError.error.message, "E");
                        } else {
                            oController.openDialogMessageText(oError, "E");
                        }
                    });
                } else {
                    //MessageToast.show(oController.getResourceBundle().getText("noDataToSend")) 
                    oController.openDialogMessageText(oController.getResourceBundle().getText("noDataToSend"), "E");
                    oBusyDialog.close();
                }
                oController.pComponentsToClosing.close();
            },

            onCloseComponentsToClosingDialogDialog: function (oEvent) {
                oController.pComponentsToClosing.close()
            },

            onTechnicalCompleteOrder: async function (oEvent) {
                oController.action = oEvent.getParameters().id.split("::")[oEvent.getParameters().id.split("::").length - 1]
                var found = false
                if (oController.byId("TableCombined").getSelectedContexts().length === 1) {
                    // cerco se esiste almeno un componente con ricarica stock
                    var oModel = oController.getView().getModel(); // OData V4 Model
                    var oListBinding = oModel.bindList("/ZZ1_PRODUCTION_COCKPIT_API('" + oController.byId("TableCombined").getSelectedContexts()[0].getObject().ID + "')/to_ZZ1_C_COMBORDER_COMP");
                    oController.oBusyDialog = new sap.m.BusyDialog();
                    oController.oBusyDialog.open();

                    oListBinding.requestContexts().then(async aContexts => {
                        oController.oBusyDialog.close();

                        console.log("Dati letti:", aContexts.map(oContext => oContext.getObject()));

                        var dataProductionOrder = await oController.getProductionOrder()
                        var tableCombined = oController.byId("TableCombined")

                        var oBusyDialog = new sap.m.BusyDialog();
                        oBusyDialog.open();
                        const oModel = oController.getView().getModel();
                        var oBindingContext = oModel.bindContext("/TechnicalCompleteOrder(...)");

                        oBindingContext.setParameter("OrderID",
                            dataProductionOrder //'1234567'
                        );

                        oBindingContext.execute().then((oResult) => {
                            var oContext = oBindingContext.getBoundContext();

                            var message = ""
                            var value = oContext.getObject().value
                            var messageArray = value.split("|")

                            if (!value || value.trim() === "") {
                                message = value
                                oController.openDialogMessageText(message, "E");

                                //refresh tabella Combined
                                if (tableCombined && tableCombined.getMDCTable().clearSelection) {
                                    tableCombined.getMDCTable().clearSelection();
                                }
                                sap.ui.getCore().byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content-innerTable").getBinding("rows").refresh()
                                oBusyDialog.close();
                            } else {
                                if (oContext.getObject().value.indexOf("Error") > -1) {
                                    sap.m.MessageBox.error(
                                        oController.getResourceBundle().getText("followingErrorsFound") + "\n\n" +
                                        messageArray.join("\n"),
                                        {
                                            title: oController.getResourceBundle().getText("errors")
                                        }
                                    );

                                    //refresh tabella Combined
                                    if (tableCombined && tableCombined.getMDCTable().clearSelection) {
                                        tableCombined.getMDCTable().clearSelection();
                                    }
                                    sap.ui.getCore().byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content-innerTable").getBinding("rows").refresh()
                                    oBusyDialog.close();
                                } else {
                                    sap.m.MessageBox.success(
                                        messageArray.join("\n"),
                                        {
                                            title: oController.getResourceBundle().getText("success"),
                                            onClose: function () {
                                                var data = []
                                                found = false
                                                var objectCopy = {}
                                                for (var i = 0; i < aContexts.map(oContext => oContext.getObject()).length; i++) {
                                                    objectCopy = {}
                                                    if (aContexts.map(oContext => oContext.getObject())[i].requirementtype !== 'BB') {

                                                    } else {
                                                        found = true
                                                        objectCopy = aContexts.map(oContext => oContext.getObject())[i]
                                                        objectCopy.selectedCheckboxRecharge = true
                                                        objectCopy.editableCheckboxRecharge = true
                                                        data.push(objectCopy)
                                                    }
                                                }

                                                if (found) {
                                                    // apro popup con componenti che hanno flag di ricarica stock
                                                    if (oController.pComponentsToClosing === null || oController.pComponentsToClosing === undefined) {
                                                        oController.pComponentsToClosing = sap.ui.xmlfragment(oController.getView().getId(), "productioncockpitapp.ext.Fragment.ComponentsToClosing", oController);
                                                        oController.getView().addDependent(oController.pComponentsToClosing);
                                                    }
                                                    const oModel = new sap.ui.model.json.JSONModel(data);
                                                    oController.getView().setModel(oModel, "SelectedComponentsToClosing");
                                                    oController.pComponentsToClosing.open()
                                                    oBusyDialog.close();
                                                    return;
                                                }

                                                //refresh tabella Combined
                                                if (tableCombined && tableCombined.getMDCTable().clearSelection) {
                                                    tableCombined.getMDCTable().clearSelection();
                                                }
                                                sap.ui.getCore().byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content-innerTable").getBinding("rows").refresh()
                                                oBusyDialog.close();
                                            }
                                        }
                                    );
                                }
                            }
                        }).catch((oError) => {
                            oBusyDialog.close();
                            if (oError.error !== undefined && oError.error !== null) {
                                oController.openDialogMessageText(oError.error.message, "E");
                            } else {
                                oController.openDialogMessageText(oError, "E");
                            }
                        });
                    }).catch(err => {
                        console.log("Errore nella chiamata OData:", err);
                    });

                } else {
                    MessageToast.show(oController.getResourceBundle().getText("selectOnlyOneRecord"))
                }
            },

            onRelaseOrder: async function (oEvent) {
                var dataProductionOrder = await oController.getProductionOrder()
                var tableCombined = oController.byId("TableCombined")
                const oBinding = tableCombined.getRowBinding();
                //alert(JSON.stringify(dataProductionOrder))

                var oBusyDialog = new sap.m.BusyDialog();
                oBusyDialog.open();
                const oModel = oController.getView().getModel();
                var oBindingContext = oModel.bindContext("/ReleaseOrder(...)");

                oBindingContext.setParameter("OrderID",
                    dataProductionOrder//'1234567'
                );

                oBindingContext.execute().then((oResult) => {
                    var oContext = oBindingContext.getBoundContext();

                    var message = ""
                    var messageArray = oContext.getObject().value.split("|")
                    if (messageArray.length === 0) {
                        message = oContext.getObject().value
                        oController.openDialogMessageText(message, "E");
                    } else {
                        if (oContext.getObject().value.indexOf("Error") > -1) {
                            sap.m.MessageBox.error(
                                oController.getResourceBundle().getText("followingErrorsFound") + "\n\n" +
                                messageArray.join("\n"),
                                {
                                    title: oController.getResourceBundle().getText("errors")
                                }
                            );
                        } else {
                            sap.m.MessageBox.success(
                                messageArray.join("\n"),
                                {
                                    title: oController.getResourceBundle().getText("success")
                                }
                            );
                        }
                    }
                    //refresh tabella Combined
                    if (tableCombined && tableCombined.getMDCTable().clearSelection) {
                        tableCombined.getMDCTable().clearSelection();
                    }
                    sap.ui.getCore().byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined-content-innerTable").getBinding("rows").refresh()
                    //tableCombined.getBinding("rows").refresh()
                    oBusyDialog.close();
                }).catch((oError) => {
                    oBusyDialog.close();
                    if (oError.error !== undefined && oError.error !== null) {
                        oController.openDialogMessageText(oError.error.message, "E");
                    } else {
                        oController.openDialogMessageText(oError, "E");
                    }
                });
            },

            getProductionOrder: async function () {
                // recupero ordini di produzione
                var arrayProductionOrder = []
                var dataProductionOrder = []
                // recupero array master order
                if (oController.byId("IconTabFilterId").getSelectedKey() === "combined") {
                    var dataMasterTable = this.byId("TableMaster").getRowBinding().aContexts
                    for (var i = 0; i < sap.ui.getCore().byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined").getSelectedContexts().length; i++) {
                        var combinedOrder = sap.ui.getCore().byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined").getSelectedContexts()[i].getObject().CombinedOrder
                        for (var y = 0; y < dataMasterTable.length; y++) {
                            if (dataMasterTable[y].getObject().CombinedOrder === combinedOrder) {
                                var masterOrder = dataMasterTable[y].getObject().MasterProductionOrder
                                dataProductionOrder.push(masterOrder)
                            }
                        }
                    }
                }
                const oModelView = oController.getView().getModel();
                var oBindingContext = await oModelView.bindContext("/GetOrdersList(...)");
                oBindingContext.setParameter("MasterOrderList",
                    dataProductionOrder
                );

                await oBindingContext.execute().then((oResult) => {
                    var oContext = oBindingContext.getBoundContext();
                    if (oContext.getObject().value.length > 0) {
                        for (var z = 0; z < oContext.getObject().value.length; z++) {
                            arrayProductionOrder.push(oContext.getObject().value[z].ManufacturingOrder)
                        }
                    }

                }).catch((oError) => {
                    oBusyDialog.close();
                    if (oError.error !== undefined && oError.error !== null) {
                        oController.openDialogMessageText(oError.error.message, "E");
                    } else {
                        oController.openDialogMessageText(oError, "E");
                    }

                });

                return arrayProductionOrder


                /*var dataMasterTable = this.byId("TableMaster").getRowBinding().aContexts
                var dataOrderTable = this.byId("Table").getRowBinding().aContexts
                for (var i = 0; i < sap.ui.getCore().byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined").getSelectedContexts().length; i++) {
                    var combinedOrder = sap.ui.getCore().byId("productioncockpitapp::ZZ1_PRODUCTION_COCKPIT_APIMain--TableCombined").getSelectedContexts()[i].getObject().CombinedOrder
                    for (var y = 0; y < dataMasterTable.length; y++) {
                        if (dataMasterTable[y].getObject().CombinedOrder === combinedOrder) {
                            var masterOrder = dataMasterTable[y].getObject().MasterProductionOrder
                            for (var z = 0; z < dataOrderTable.length; z++) {
                                //if(dataOrderTable[z].getObject().MasterProductionOrder === masterOrder){
                                arrayProductionOrder.push(dataOrderTable[z].getObject().ManufacturingOrder)
                                //}
                            }
                        }
                    }
                }*/

            },

            onCreateOrder: function () {
                if (oController.pCreateOrderDialog === null || oController.pCreateOrderDialog === undefined) {
                    oController.pCreateOrderDialog = sap.ui.xmlfragment(this.getView().getId(), "productioncockpitapp.ext.Fragment.CreaOrdine", oController);
                    oController.getView().addDependent(oController.pCreateOrderDialog);
                }
                oController.pCreateOrderDialog.open();
            },

            onCloseCreateOrder: function () {
               oController.pCreateOrderDialog.close();
            },

            openDialogMessageText: function (text, messType) {
                const isError = messType === "E";
                const isSuccess = messType === "I" || messType === "S";

                let vTitle = "Message";
                let vState = "Error";

                if (isError) {
                    vTitle = this.getResourceBundle().getText("errorTitle");
                    vState = "Error";
                } else if (isSuccess) {
                    vTitle = this.getResourceBundle().getText("successTitle");
                    vState = "Success";
                }

                var dialog = new Dialog({
                    title: vTitle,
                    type: "Message",
                    state: vState,
                    content: new sap.m.Text({
                        text: text
                    }),

                    beginButton: new sap.m.Button({
                        text: "OK",
                        press: function () {
                            dialog.close();
                        }
                    }),
                    afterClose: function () {
                        dialog.destroy();
                    }
                });

                dialog.open();
            },

            onCloseROLDialog: function () {
                oController.pROLDialog.close();
            },

            determineLifeCycleStatus: function (O, a) {
                if (O === "" && a === "X") {
                    O = "Y";
                }
                switch (O) {
                    case "X":
                        return "Success";
                    case "Y":
                        return "Warning";
                }
                return "None";
            },
            determineLifeCycleStatusText: function (S, a) {
                switch (a) {
                    case "X1":
                        if (S === 0) {
                            return this.getView().getModel("i18n").getResourceBundle().getText("Created");
                        } else {
                            return S + "% " + this.getView().getModel("i18n").getResourceBundle().getText("Created");
                        }
                    case "X2":
                        if (S === 0) {
                            return this.getView().getModel("i18n").getResourceBundle().getText("Released");
                        } else {
                            return S + "% " + this.getView().getModel("i18n").getResourceBundle().getText("Released");
                        }
                    case "X3":
                        if (S === 0) {
                            return this.getView().getModel("i18n").getResourceBundle().getText("Confirmed");
                        } else {
                            return S + "% " + this.getView().getModel("i18n").getResourceBundle().getText("Confirmed");
                        }
                    case "X4":
                        if (S === 0) {
                            return this.getView().getModel("i18n").getResourceBundle().getText("Delivered");
                        } else {
                            return S + "% " + this.getView().getModel("i18n").getResourceBundle().getText("Delivered");
                        }
                    case "X5":
                        if (S === 0) {
                            return this.getView().getModel("i18n").getResourceBundle().getText("TechnicallyCompleted");
                        } else {
                            return S + "% " + this.getView().getModel("i18n").getResourceBundle().getText("TechnicallyCompleted");
                        }
                    case "X6":
                        if (S === 0) {
                            return this.getView().getModel("i18n").getResourceBundle().getText("Closed");
                        } else {
                            return S + "% " + this.getView().getModel("i18n").getResourceBundle().getText("Closed");
                        }
                    case "X7":
                        if (S === 0) {
                            return this.getView().getModel("i18n").getResourceBundle().getText("Deleted");
                        } else {
                            return S + "% " + this.getView().getModel("i18n").getResourceBundle().getText("Deleted");
                        }
                }
                return "";
            },
            determineIssueTypeText: function (I, a) {
                switch (a) {
                    case "X1":
                        if (I === "X") {
                            return this.getView().getModel("i18n").getResourceBundle().getText("OnHold");
                        } else {
                            return this.getView().getModel("i18n").getResourceBundle().getText("NotOnHold");
                        }
                    case "X2":
                        if (I === "X") {
                            return this.getView().getModel("i18n").getResourceBundle().getText("Delay");
                        } else {
                            return this.getView().getModel("i18n").getResourceBundle().getText("NoDelay");
                        }
                    case "X3":
                        if (I === "X") {
                            return this.getView().getModel("i18n").getResourceBundle().getText("MissingComponents ");
                        } else {
                            return this.getView().getModel("i18n").getResourceBundle().getText("NoMissingComponents");
                        }
                    case "X4 ":
                        if (I === "X") {
                            return this.getView().getModel("i18n ").getResourceBundle().getText("QuantityIssue");
                        } else {
                            return this.getView().getModel("i18n").getResourceBundle().getText("NoQuantityIssue");
                        }
                    case "X5":
                        if (I === "X") {
                            return this.getView().getModel("i18n").getResourceBundle().getText("QualityIssue");
                        } else {
                            return this.getView().getModel("i18n").getResourceBundle().getText("NoQualityIssue");
                        }
                }
                return "";
            },
            determineColor: function (I) {
                if (I === "X") {
                    return "Negative";
                }
                return "NonInteractive";
            }

        });
    }
);
