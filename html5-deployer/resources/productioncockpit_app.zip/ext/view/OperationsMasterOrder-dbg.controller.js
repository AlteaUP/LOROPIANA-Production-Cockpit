sap.ui.define(
    [
        'sap/fe/core/PageController',
        'sap/ui/model/json/JSONModel',
        "sap/m/Dialog",
        'sap/m/MessageToast'

    ],
    function (PageController, JSONModel, Dialog, MessageToast) {
        'use strict';

        var oController;

        return PageController.extend('productioncockpitapp.ext.view.Operations', {
            /**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             * @memberOf productioncockpitapp.ext.view.Operations
             */
            onInit: function () {
                oController = this;
                this.getView().attachModelContextChange(() => {
                    const ctx = this.getView().getBindingContext();
                    if (ctx !== undefined && ctx !== null) {
                        var newPathSplitted = ctx.sPath.split("/");
                        var newPath = newPathSplitted[0] + "/" + newPathSplitted[1];
                        ctx.sPath = newPath
                    }
                    console.log("View binding context:", ctx && ctx.getPath());
                });
                this.byId("TableOperations").attachSelectionChange(function (oEvent) {
                    // recupero CBO ABILITA/AVANZA
                    var oModel = oController.getView().getModel(); // OData V4 Model
                    var oListBinding = oModel.bindList("/ZZ1_ABILITA_AVANZA");

                    oListBinding.requestContexts().then(function (aContexts) {
                        if (aContexts.length > 0) {
                            var oData = aContexts[0].getObject(); 
                            var bValore = oData.Enabled; 

                            oController._bAbilitaAvanza = bValore;

                            console.log("Valore boolean:", oController._bAbilitaAvanza);
                        }
                    }).catch(function (err) {
                            console.error("Errore nella chiamata OData:", err);
                        });

                    var aSelected = oEvent.getParameters().selectedContext;

                    if (aSelected.length > 0) {
                        oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::changeWCMasterAction").setEnabled(true);
                        oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::addPhaseMasterAction").setEnabled(true);
                        oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::deletePhaseMasterAction").setEnabled(true);
                        oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::movePhaseMasterAction").setEnabled(true);
                        oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::modifyPhaseMasterAction").setEnabled(true);

                        if (aSelected.length > 1) {
                            oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::movePhaseMasterAction").setEnabled(false);
                            oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::addPhaseMasterAction").setEnabled(false);
                            oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::modifyPhaseMasterAction").setEnabled(false);

                            var bAllQtaNotZero = aSelected.every(function (oCtx) {
                                return Number(oCtx.getObject().SumOpTotalConfirmedYieldQty) !== 0;
                            });

                            if (bAllQtaNotZero) {
                                oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::changeWCMasterAction").setEnabled(false);
                            }

                        } else if (aSelected.length === 1) {
                            var oObj = aSelected[0].getObject();

                            if (oObj.ExtProcgOperationHasSubcontrg === "" && !oController._bAbilitaAvanza) {
                                oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::movePhaseMasterAction").setEnabled(false);
                            }

                            if (Number(oObj.SumOpTotalConfirmedYieldQty) !== 0) {
                                oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::addPhaseMasterAction").setEnabled(false);
                                oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::changeWCMasterAction").setEnabled(false);
                            }
                        }
                    } else {
                        oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::changeWCMasterAction").setEnabled(false);
                        oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::addPhaseMasterAction").setEnabled(false);
                        oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::deletePhaseMasterAction").setEnabled(false);
                        oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::movePhaseMasterAction").setEnabled(false);
                        oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content::CustomAction::modifyPhaseMasterAction").setEnabled(false);
                    }
                });
            },

            loadTableData: function (oEvent) {
                var mBindingParams = oEvent.getParameter("collectionBindingInfo");
                //Event handlers for the binding
                mBindingParams.collectionBindingInfo.events = {
                    "dataReceived": function (oEvent) {
                        var aReceivedData = oEvent.getParameter('data');

                        // modifica DL - 16/12/2025 - colore righe se operazione chiusa e tolgo selezione
                        var oMDCTable = oController.byId("TableOperations").getMDCTable();

                        var intervalId = setInterval(function () {
                            var aRows = oMDCTable._oTable.getRows();
                            if (aRows.length > 0) {
                                // Cella pronta, applica editMode
                                aRows.forEach(function (oRow) {
                                    // rimuovo classi precedenti
                                    oRow.removeStyleClass("grayBackground");

                                    if (oRow.getBindingContext() !== null) {
                                        if (oRow.getBindingContext().getProperty("OperationIsDeleted") === "X") {
                                            oRow.addStyleClass("grayBackground");
                                            /*var idToRemove = oRow.getId() + "-selectMulti"
                                            sap.ui.getCore().byId(idToRemove).setVisible(false)*/
                                            var parentId = oRow.getParent().getId()
                                            var countRow = oRow.getId().substring(oRow.getId().length - 1, oRow.getId().length)
                                            var idToRemove = parentId + "-rowsel" + countRow
                                            document.getElementById(idToRemove).style.visibility = "hidden";
                                        }
                                    }

                                });
                                clearInterval(intervalId); // ferma il polling
                            }
                        }, 100);
                        // modifica DL - 16/12/2025 - colore righe se operazione chiusa e tolgo selezione - FINE

                        // gestione errore
                        if (oEvent.mParameters.error !== undefined && oEvent.mParameters.error !== null) {
                            oController.openDialogMessageText(oEvent.mParameters.error.message, "E");
                        }
                    },
                    //More event handling can be done here
                };

                //delete mBindingParams.collectionBindingInfo.parameters.$$getKeepAliveContext
            },

            onFreeFlagSelectMaster: function (oEvent) {
                const bSelected = oEvent.getParameter("selected");
                const oCtx = oEvent.getSource().getBindingContext();
                if (!oCtx) return;

                const oModel = oCtx.getModel();
                const sPath = oCtx.getPath();

                const sPricePath = sPath + "/OpExternalProcessingPrice";
                const sOldPath = sPath + "/OpExternalProcessingPrice_OLD";

                if (bSelected) {
                    const vOld = oModel.getProperty(sOldPath);
                    if (vOld === undefined || vOld === null) {
                        const vCurrent = oModel.getProperty(sPricePath);
                        oModel.setProperty(sOldPath, vCurrent);
                    }
                    oModel.setProperty(sPricePath, 0);
                } else {
                    // ripristina
                    const vRestore = oModel.getProperty(sOldPath);
                    if (vRestore !== undefined && vRestore !== null) {
                        oModel.setProperty(sPricePath, vRestore);
                        oModel.setProperty(sOldPath, null);
                    }
                }
            },

            onValidateRequired: function (oEvent) {
                if (!this._isSubcontracting) {
                    return;
                }
                const oControl = oEvent.getSource();
                const sValue = (oControl.getValue() || "").trim();

                if (!sValue) {
                    oControl.setValueState("Error");
                } else {
                    oControl.setValueState("None");
                }
            },
            onCloseOperationsChangeWCMasterDialog: function () {
                oController.pOperationsChangeWCMasterDialog.close();
            },

            onCloseOperationsAddPhaseMasterDialog: function () {
                oController.pOperationsAddPhaseMasterDialog.close();
            },

            onCloseOperationsMovePhaseDialog: function () {
                const ddtDate = this.byId("ddtDateId");
                const ddt = this.byId("ddtId");
                //pulisco campi
                ddtDate.setValue("");
                ddt.setValue("");
                oController.pOperationsMovePhaseMasterDialog.close();
            },

            onConfirmOperationsMovePhaseDialog: function () {
                console.log("onConfirmOperationsMovePhaseDialog");
                const oTableModel = this.byId("OperationsMovePhaseTableId")
                    .getModel("local")
                    .getProperty("/SelectedOperationsMovePhase") || [];;
                //blocco se ddt e ddt_date sono required e non compilati
                if (oTableModel[0].ExtProcgOperationHasSubcontrg === "X") {
                    const oDdt = this.byId("ddtId");
                    const oDdtDate = this.byId("ddtDateId");

                    const sDdt = (oDdt.getValue() || "").trim();
                    const sDateValue = (oDdtDate.getValue() || "").trim();

                    let bValid = true;
                    // DDT
                    if (!sDdt) {
                        oDdt.setValueState("Error");
                        bValid = false;
                    } else {
                        oDdt.setValueState("None");
                    }
                    // Data
                    if (!sDateValue) {
                        oDdtDate.setValueState("Error");
                        bValid = false;
                    } else {
                        oDdtDate.setValueState("None");
                    }
                    if (!bValid) {
                        return; // blocca
                    }
                }
                var dataToSend = []
                var dataObjectToSend = {}
                // Prendo il valore dell’Input
                const sDdt = this.byId("ddtId").getValue() || "";

                // Prendo la data dal DatePicker
                const oDatePicker = this.byId("ddtDateId");
                const sDate = oDatePicker.getValue() || null;

                for (var i = 0; i < this.byId("OperationsMovePhaseTableId").getItems().length; i++) {
                    var path = this.byId("OperationsMovePhaseTableId").getItems()[i].getBindingContext("local").sPath
                    var object = this.byId("OperationsMovePhaseTableId").getModel("local").getObject(path)
                    dataObjectToSend = {}
                    dataObjectToSend.id = String(i + 1).padStart(3, "0");//"001"                    
                    dataObjectToSend.CprodOrd = object.CprodOrd
                    dataObjectToSend.FshMprodOrd = object.MasterProductionOrder
                    dataObjectToSend.matnr = object.Product
                    dataObjectToSend.werks = object.Plant
                    dataObjectToSend.meins = object.ProductionUnit
                    dataObjectToSend.yield = Number(object.QtyToConfirm)
                    dataObjectToSend.ext_flag = object.ExtProcgOperationHasSubcontrg
                    dataObjectToSend.intermed_flag = object.IntermediatePhaseIndicator
                    dataObjectToSend.po_num = object.PurchaseOrder
                    dataObjectToSend.po_flag = object.flagPurchaseOrder
                    dataObjectToSend.ddt = sDdt;
                    dataObjectToSend.ddt_date = sDate
                    /*dataObjectToSend.scrap = Number(object.QtyToDiscard)
                    dataObjectToSend.rework = Number(object.QtyToRework)*/
                    dataObjectToSend.vornr = object.ManufacturingOrderOperation
                    dataObjectToSend.plnfl = object.ManufacturingOrderSequence
                    /*if(oController.byId("generateWIPbatchCheckBoxId").getSelected()){
                        dataObjectToSend.flwip = "X"
                    } else {
                        dataObjectToSend.flwip = ""
                    }
                    dataObjectToSend.reason = object.Reason*/
                    dataToSend.push(dataObjectToSend)
                }

                var oBusyDialog = new sap.m.BusyDialog();
                oBusyDialog.open();

                const oModel = oController.getView().getModel();
                var oBindingContext = oModel.bindContext("/ConfODP(...)");
                oBindingContext.setParameter("Record",
                    dataToSend
                );

                if (dataToSend.length > 0) {
                    oBindingContext.execute().then((oResult) => {
                        var oContext = oBindingContext.getBoundContext();
                        var v = oContext.getObject().value;
                        var s = (typeof v === "string") ? v : JSON.stringify(v ?? "");
                        if (s.includes("Error")) {
                            oController.openDialogMessageText(oContext.getObject().value, "E");
                        } else {
                            oController.openDialogMessageText(oContext.getObject().value, "S");
                        }
                       /*  if (oContext.getObject().value.to_confodp[0].fl_err_o) {
                            oController.openDialogMessageText(oContext.getObject().value.to_confodp[0].log_mess_o, "E");
                        } else {
                            oController.openDialogMessageText(oContext.getObject().value.to_confodp[0].log_mess_o, "S");
                        } */
                        setTimeout(() => {
                            sap.ui.getCore().byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content-innerTable").getBinding("rows").refresh()
                        }, 1000);
                        sap.ui.getCore().byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations").getMDCTable().clearSelection()
                        oController.pOperationsMovePhaseMasterDialog.close()
                        //MessageToast.show(oController.getResourceBundle().getText("done"))                            
                        //sap.ui.getCore().byId("productioncockpitapp::ZZ1_C_COMBINEDORDER_COMPComponentsPage--TableCombinedComponents-content-innerTable-table").getBinding("rows").refresh()
                        oBusyDialog.close();

                    }).catch((oError) => {
                        oBusyDialog.close();
                        if (oError.error !== undefined && oError.error !== null) {
                            oController.openDialogMessageText(oError.error.message, "E");
                        } else {
                            oController.openDialogMessageText(oError, "E");
                        }
                    });
                } else {
                    //MessageToast.show(oController.getResourceBundle().getText("noDataToSend"))                     
                    oController.openDialogMessageText(oController.getResourceBundle().getText("noDataToSend"), "E");
                    oBusyDialog.close();
                }
                /*var oModel = this.getView().getModel();
 
                 var payload = {
                     id: "001",
                     to_confodp: dataToSend
                 };
 
                 oBusyDialog.open();
 
                 oModel.callFunction("/MovePhase", {
                     method: "POST",
                     urlParameters: payload,
                     success: function(oData, response) {
                         // ✅ Qui hai il risultato della Action
                         if(oData.status === "Error") {
                             oController.openDialogMessageText(oData.message, "E");
                         } else {
                             oController.openDialogMessageText(oData.message || "Operazione completata", "S");
                         }
                         oBusyDialog.close();
                     },
                     error: function(oError) {
                         oController.openDialogMessageText(oError.message || "Errore sconosciuto", "E");
                         oBusyDialog.close();
                     }
                 });*/
            },

            onActionOperationMaster: async function (oEvent) {
                var buttonId = oEvent.getParameters().id.split("::")[oEvent.getParameters().id.split("::").length - 1]
                // controllo quale pulsante ho selezionato
                switch (buttonId) {
                    case "changeWCMasterAction":
                        // code block
                        oController.buttonSelected = "changeWC"
                        break;
                    case "addPhaseMasterAction":
                        // code block
                        oController.buttonSelected = "addPhase"
                        break;
                    case "deletePhaseMasterAction":
                        // code block
                        oController.buttonSelected = "deletePhase"
                        break;
                    case "movePhaseMasterAction":
                        // code block
                        oController.buttonSelected = "movePhase"
                        break;
                    case "modifyPhaseMasterAction":
                        oController.buttonSelected = "modifyPhase"
                        break;
                    default:
                        // code block
                        oController.buttonSelected = ""
                }
                if (oController.buttonSelected === "changeWC") {
                    if (oController.pOperationsChangeWCMasterDialog === null || oController.pOperationsChangeWCMasterDialog === undefined) {
                        oController.pOperationsChangeWCMasterDialog = sap.ui.xmlfragment(this.getView().getId(), "productioncockpitapp.ext.Fragment.OperationsChangeWCMasterDialog", oController);
                        oController.getView().addDependent(oController.pOperationsChangeWCMasterDialog);
                    }

                    oController.pOperationsChangeWCMasterDialog.open();

                    var selectedOperationsMasterArray = []
                    var selectedOperationsMasterObject = {}
                    for (var i = 0; i < oController.byId("TableOperations").getSelectedContexts().length; i++) {
                        selectedOperationsMasterObject = oController.byId("TableOperations").getSelectedContexts()[i].getObject()
                        //Escludi record con sumOpTotalConfirmedYieldQty diverso da 0
                        if (Number(selectedOperationsMasterObject.SumOpTotalConfirmedYieldQty) !== 0) {
                            continue;
                        }
                        selectedOperationsMasterObject.NewMaterial = selectedOperationsMasterObject.Material
                        selectedOperationsMasterArray.push(selectedOperationsMasterObject)
                    }

                    var oTable = oController.byId("OperationsChangeWCMasterTableId");

                    var oModel = new JSONModel();
                    oModel.setData({ SelectedOperationsChangeWCMaster: selectedOperationsMasterArray })
                    oTable.setModel(oModel);
                } else if (oController.buttonSelected === "addPhase") {
                    if (oController.pOperationsAddPhaseMasterDialog === null || oController.pOperationsAddPhaseMasterDialog === undefined) {
                        oController.pOperationsAddPhaseMasterDialog = sap.ui.xmlfragment(this.getView().getId(), "productioncockpitapp.ext.Fragment.OperationsAddPhaseMasterDialog", oController);
                        oController.getView().addDependent(oController.pOperationsAddPhaseMasterDialog);
                    }

                    if (oController.buttonSelected === "modifyPhase") {
                        oController.pOperationsAddPhaseMasterDialog.setTitle(oController.getResourceBundle().getText("modifyPhaseMaster"))
                    } else {
                        oController.pOperationsAddPhaseMasterDialog.setTitle(oController.getResourceBundle().getText("addPhaseMaster"))
                    }

                    oController.pOperationsAddPhaseMasterDialog.open();

                    var selectedOperationsMasterArray = []
                    var selectedOperationsMasterObject = {}
                    for (var i = 0; i < oController.byId("TableOperations").getSelectedContexts().length; i++) {
                        selectedOperationsMasterObject = oController.byId("TableOperations").getSelectedContexts()[i].getObject()
                        selectedOperationsMasterObject.NewMaterial = selectedOperationsMasterObject.Material
                        selectedOperationsMasterObject.MaterialGroupEditable = true
                        selectedOperationsMasterObject.ManufacturingOrderOperationEditable = true
                        selectedOperationsMasterObject.MfgOrderOperationTextEditable = true
                        selectedOperationsMasterObject.SupplierEditable = true
                        selectedOperationsMasterObject.WorkCenterEditable = true
                        selectedOperationsMasterObject.WorkCenterInternalID_1_TextEditable = true
                        selectedOperationsMasterObject.OperationControlProfileEditable = true
                        //in addPhase applico maggiorazione di "5" al campo operation
                        let op = selectedOperationsMasterObject.ManufacturingOrderOperation;
                        let newOp = (parseInt(op, 10) + 5)
                            .toString()
                            .padStart(op.length, '0');
                        selectedOperationsMasterObject.ManufacturingOrderOperation = newOp;
                        selectedOperationsMasterArray.push(selectedOperationsMasterObject)
                    }

                    var oTable = oController.byId("OperationsAddPhaseMasterTableId");

                    var oModel = new JSONModel();
                    oModel.setData({ SelectedOperationsAddPhaseMaster: selectedOperationsMasterArray })
                    oTable.setModel(oModel);
                } else if (oController.buttonSelected === "modifyPhase") {
                    if (oController.byId("TableOperations").getSelectedContexts().length === 1) {
                        if (oController.pOperationsAddPhaseMasterDialog === null || oController.pOperationsAddPhaseMasterDialog === undefined) {
                            oController.pOperationsAddPhaseMasterDialog = sap.ui.xmlfragment(this.getView().getId(), "productioncockpitapp.ext.Fragment.OperationsAddPhaseMasterDialog", oController);
                            oController.getView().addDependent(oController.pOperationsAddPhaseMasterDialog);
                        }

                        if (oController.buttonSelected === "modifyPhase") {
                            oController.pOperationsAddPhaseMasterDialog.setTitle(oController.getResourceBundle().getText("modifyPhaseMaster"))
                        } else {
                            oController.pOperationsAddPhaseMasterDialog.setTitle(oController.getResourceBundle().getText("addPhaseMaster"))
                        }

                        oController.pOperationsAddPhaseMasterDialog.open();

                        var selectedOperationsMasterArray = []
                        var selectedOperationsMasterObject = {}
                        for (var i = 0; i < oController.byId("TableOperations").getSelectedContexts().length; i++) {
                            selectedOperationsMasterObject = oController.byId("TableOperations").getSelectedContexts()[i].getObject()
                            selectedOperationsMasterObject.NewMaterial = selectedOperationsMasterObject.Material
                            selectedOperationsMasterObject.MaterialGroupEditable = false
                            selectedOperationsMasterObject.ManufacturingOrderOperationEditable = false
                            selectedOperationsMasterObject.MfgOrderOperationTextEditable = false
                            selectedOperationsMasterObject.SupplierEditable = false
                            selectedOperationsMasterObject.WorkCenterEditable = false
                            selectedOperationsMasterObject.WorkCenterInternalID_1_TextEditable = false
                            selectedOperationsMasterObject.OperationControlProfileEditable = false
                            selectedOperationsMasterArray.push(selectedOperationsMasterObject)
                        }

                        var oTable = oController.byId("OperationsAddPhaseMasterTableId");

                        var oModel = new JSONModel();
                        oModel.setData({ SelectedOperationsAddPhaseMaster: selectedOperationsMasterArray })
                        oTable.setModel(oModel);
                    } else {
                        MessageToast.show(oController.getResourceBundle().getText("selectOnlyOneRecord"))
                    }
                } else if (oController.buttonSelected === "movePhase") {
                    if (oController.byId("TableOperations").getSelectedContexts().length === 1) {
                        if (oController.pOperationsMovePhaseMasterDialog === null || oController.pOperationsMovePhaseMasterDialog === undefined) {
                            oController.pOperationsMovePhaseMasterDialog = sap.ui.xmlfragment(this.getView().getId(), "productioncockpitapp.ext.Fragment.OperationsMovePhaseDialog", oController);
                            oController.getView().addDependent(oController.pOperationsMovePhaseMasterDialog);
                        }

                        // modifica DL - controllo quale riga ho selezionato, se è l'ultima disabilito il flag WIP batch
                        if (oController.byId("TableOperations").getRowBinding().getLength() - 1 === oController.byId("TableOperations").getMDCTable().getSelectedContexts()[0].getIndex()) {
                            oController.byId("generateWIPbatchCheckBoxId").setEnabled(false)
                            oController.byId("generateWIPbatchCheckBoxId").setSelected(false)
                        } else {
                            oController.byId("generateWIPbatchCheckBoxId").setEnabled(true)
                            oController.byId("generateWIPbatchCheckBoxId").setSelected(true)
                        }

                        oController.pOperationsMovePhaseMasterDialog.open();

                        // chiamo action per recupero dettagli del materiale
                        var oBusyDialog = new sap.m.BusyDialog();
                        oBusyDialog.open();

                        //rendo obbligatori i campi ddt e ddt_date se ExtProcgOperationHasSubcontrg é true
                        const itemSelected = oController.byId("TableOperations").getSelectedContexts()[0].getObject();
                        const bSubcontrg = itemSelected.ExtProcgOperationHasSubcontrg === "X";
                        this._isSubcontracting = bSubcontrg;

                        const oDdt = oController.byId("ddtId");        // id campo DDT
                        const oDdtDate = oController.byId("ddtDateId"); // id DatePicker

                        if (oDdt && oDdt.setRequired) {
                            oDdt.setRequired(bSubcontrg);
                        }

                        if (oDdtDate && oDdtDate.setRequired) {
                            oDdtDate.setRequired(bSubcontrg);
                        }

                        //calcolo il campo SumopTotalConfirmetYieldQty da mostrare nella popup
                        var oTable = oController.byId("TableOperations");
                        const oMDCTable = oTable.getMDCTable && oTable.getMDCTable();
                        console.log("oMDCTable", oMDCTable);

                        const oInnerTable = oMDCTable && oMDCTable._oTable;
                        console.log("oInnerTable", oInnerTable);

                        const oBinding = oInnerTable && (oInnerTable.getBinding("items") || oInnerTable.getBinding("rows"));
                        console.log("oBinding", oBinding);

                        var oSelectedObject = oTable.getSelectedContexts()[0].getObject();

                        // flag
                        var bHasPreviousOperation = false;

                        //var sPreviousSumOpTotalConfirmedYieldQty = null;

                        // recupero tutti i record della tabella                       
                        var aContexts = oBinding.getContexts();
                        var aAllObjects = aContexts.map(function (oContext) {
                            return oContext.getObject();
                        });

                        // sequenza e operazione del record selezionato
                        var sSelectedSequence = oSelectedObject.ManufacturingOrderSequence;
                        var iSelectedOperation = Number(oSelectedObject.ManufacturingOrderOperation);

                        // filtro i record con la stessa sequenza
                        var aSameSequence = aAllObjects.filter(function (oItem) {
                            return oItem.ManufacturingOrderSequence === sSelectedSequence
                                && oItem.OperationIsDeleted !== "X";
                        });

                        // se c'è solo il record selezionato, non può esistere una precedente
                        if (aSameSequence.length > 1) {
                            // ordino per operazione numerica crescente
                            aSameSequence.sort(function (a, b) {
                                return Number(a.ManufacturingOrderOperation) - Number(b.ManufacturingOrderOperation);
                            });

                            // trovo l'indice del record selezionato nell'array ordinato
                            var iSelectedIndex = aSameSequence.findIndex(function (oItem) {
                                return Number(oItem.ManufacturingOrderOperation) === iSelectedOperation;
                            });

                            this.sPreviousSumOpTotalConfirmedYieldQty = null;
                            // se l'indice è > 0, esiste una operazione precedente
                            if (iSelectedIndex > 0) {
                                bHasPreviousOperation = true;

                                var oPreviousOperation = aSameSequence[iSelectedIndex - 1];
                                this.sPreviousSumOpTotalConfirmedYieldQty = oPreviousOperation.SumOpTotalConfirmedYieldQty;
                            }
                        }

                        var dataToSend = {}
                        dataToSend.MasterProductionOrder = oController.byId("TableOperations").getSelectedContexts()[0].getObject().MasterProductionOrder
                        dataToSend.ManufacturingOrderSequence = oController.byId("TableOperations").getSelectedContexts()[0].getObject().ManufacturingOrderSequence
                        dataToSend.ManufacturingOrderOperation = oController.byId("TableOperations").getSelectedContexts()[0].getObject().ManufacturingOrderOperation
                        dataToSend.sumOpTotalConfirmedYieldQty = oController.byId("TableOperations").getSelectedContexts()[0].getObject().SumOpTotalConfirmedYieldQty
                        dataToSend.sumOpTotalConfirmedReworkQty = oController.byId("TableOperations").getSelectedContexts()[0].getObject().SumOpTotalConfirmedReworkQty
                        dataToSend.sumOpTotalConfirmedScrapQty = oController.byId("TableOperations").getSelectedContexts()[0].getObject().SumOpTotalConfirmedScrapQty
                        dataToSend.CrossPlantConfigurableProduct = oController.byId("TableOperations").getSelectedContexts()[0].getObject().CrossPlantConfigurableProduct
                        //recupero campi ExtProcgOperationHasSubcontrg - IntermediatePhaseIndicator - PurchaseOrder - FlagPurchaseOrder - Plant
                        this.ExtProcgOperationHasSubcontrg = oController.byId("TableOperations").getSelectedContexts()[0].getObject().ExtProcgOperationHasSubcontrg
                        this.IntermediatePhaseIndicator = oController.byId("TableOperations").getSelectedContexts()[0].getObject().IntermediatePhaseIndicator
                        this.PurchaseOrder = oController.byId("TableOperations").getSelectedContexts()[0].getObject().PurchaseOrder
                        this.flagPurchaseOrder = oController.byId("TableOperations").getSelectedContexts()[0].getObject().flagPurchaseOrder
                        this.Plant = oController.byId("TableOperations").getSelectedContexts()[0].getObject().Plant

                        const oModelView = oController.getView().getModel();
                        var oBindingContext = oModelView.bindContext("/GetMaterialDetails(...)");
                        oBindingContext.setParameter("oidOrdine",
                            dataToSend
                        );

                        await oBindingContext.execute().then((oResult) => {
                            var oContext = oBindingContext.getBoundContext();
                            var selectedOperationsMasterArray = []
                            var selectedOperationsMasterObject = {}
                            var vPrevQty = this.sPreviousSumOpTotalConfirmedYieldQty;
                            if (oContext.getObject().value.length > 0) {
                                for (var p = 0; p < oContext.getObject().value.length; p++) {
                                    selectedOperationsMasterObject = oContext.getObject().value[p]
                                    //selectedOperationsMasterObject.CrossPlantConfigurableProduct = oContext.getObject().value[p].matnr
                                    //selectedOperationsMasterObject.zztagliadesc = oContext.getObject().value[p].zztagliadesc
                                    //selectedOperationsMasterObject.zzcolor = oContext.getObject().value[p].zzcolor
                                    //aggiungo al model i campi ExtProcgOperationHasSubcontrg - IntermediatePhaseIndicator - PurchaseOrder - FlagPurchaseOrder - Plant
                                    selectedOperationsMasterObject.ExtProcgOperationHasSubcontrg = this.ExtProcgOperationHasSubcontrg
                                    selectedOperationsMasterObject.IntermediatePhaseIndicator = this.IntermediatePhaseIndicator
                                    selectedOperationsMasterObject.PurchaseOrder = this.PurchaseOrder
                                    selectedOperationsMasterObject.flagPurchaseOrder = this.flagPurchaseOrder
                                    selectedOperationsMasterObject.Plant = this.Plant
                                    //selectedOperationsMasterObject.QtyToConfirm = Number(selectedOperationsMasterObject.MfgOrderPlannedTotalQty) - Number(selectedOperationsMasterObject.MfgOrderConfirmedYieldQty) - Number(selectedOperationsMasterObject.MfgOrderConfirmedScrapQty)
                                    selectedOperationsMasterObject.QtyToConfirm =
                                        vPrevQty !== null && vPrevQty !== undefined && vPrevQty !== ""
                                            ? Number(vPrevQty)
                                            : (Number(selectedOperationsMasterObject.MfgOrderPlannedTotalQty) - Number(selectedOperationsMasterObject.MfgOrderConfirmedYieldQty) - Number(selectedOperationsMasterObject.MfgOrderConfirmedScrapQty));
                                    selectedOperationsMasterArray.push(selectedOperationsMasterObject)
                                }
                            }
                            var oTable = oController.byId("OperationsMovePhaseTableId");

                            var oModel = new JSONModel();
                            oModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
                            oModel.setData({ SelectedOperationsMovePhase: selectedOperationsMasterArray })
                            oTable.setModel(oModel, "local");
                            console.log("table model", this.byId("OperationsMovePhaseTableId").getModel("local"));
                            console.log("view model", this.getView().getModel("local"));

                            oBusyDialog.close();

                        }).catch((oError) => {
                            oBusyDialog.close();
                            if (oError.error !== undefined && oError.error !== null) {
                                oController.openDialogMessageText(oError.error.message, "E");
                            } else {
                                oController.openDialogMessageText(oError, "E");
                            }
                        });


                        /*var selectedOperationsMasterArray = []
                        var selectedOperationsMasterObject = {}
                        for(var i=0; i<oController.byId("TableOperations").getSelectedContexts().length; i++){
                            selectedOperationsMasterObject = oController.byId("TableOperations").getSelectedContexts()[i].getObject()
                            selectedOperationsMasterObject.NewMaterial = selectedOperationsMasterObject.Material
                            selectedOperationsMasterObject.QtyToConfirm = Number(selectedOperationsMasterObject.SumOpPlannedTotalQuantity) - Number(selectedOperationsMasterObject.SumOpTotalConfirmedYieldQty) - Number(selectedOperationsMasterObject.SumOpTotalConfirmedScrapQty)
                            selectedOperationsMasterArray.push(selectedOperationsMasterObject)
                        }

                        var oTable = oController.byId("OperationsMovePhaseTableId");
                            
                        var oModel = new JSONModel();
                        oModel.setData({ SelectedOperationsMovePhase: selectedOperationsMasterArray})
                        oTable.setModel(oModel);*/
                    } else {
                        MessageToast.show(oController.getResourceBundle().getText("selectOnlyOneRecord"))
                    }
                } else {
                    oController.onDeleteOperationsMaster()
                }
            },

            onConfirmAddPhaseMasterDialog: function (oEvent) {
                var dataToSend = []
                var dataObjectToSend = {}

                var table
                if (this.byId("OperationsAddPhaseMasterTableId") === null || this.byId("OperationsAddPhaseMasterTableId") === undefined) {
                    table = this.byId("OperationsChangeWCMasterTableId").getModel().oData.SelectedOperationsChangeWCMaster
                } else {
                    table = this.byId("OperationsAddPhaseMasterTableId").getModel().oData.SelectedOperationsAddPhaseMaster
                }

                for (var i = 0; i < table.length; i++) {
                    dataObjectToSend = {}
                    dataObjectToSend.id = "001"
                    dataObjectToSend.MasterProductionOrder = table[i].MasterProductionOrder
                    dataObjectToSend.ManufacturingOrderOperation = table[i].ManufacturingOrderOperation
                    dataObjectToSend.WorkCenter = table[i].WorkCenter
                    dataObjectToSend.Plant = table[i].Plant
                    dataObjectToSend.OperationControlProfile = table[i].OperationControlProfile
                    dataObjectToSend.MfgOrderOperationText = table[i].MfgOrderOperationText
                    dataObjectToSend.MaterialGroup = table[i].MaterialGroup
                    dataObjectToSend.unit = ""//table[i].
                    dataObjectToSend.price = Number(table[i].OpExternalProcessingPrice) //table[i].
                    dataObjectToSend.ManufacturingOrderSequence = table[i].ManufacturingOrderSequence
                    dataObjectToSend.umson = table[i].FreeFlag
                    if (oController.buttonSelected === "modifyPhase") {
                        dataObjectToSend.action = "UPD"
                    } else if (oController.buttonSelected === "addPhase") {
                        dataObjectToSend.action = "ADD"
                    } else {
                        dataObjectToSend.action = "WRK"
                    }
                    dataToSend.push(dataObjectToSend)
                }

                var oBusyDialog = new sap.m.BusyDialog();
                oBusyDialog.open();

                const oModel = oController.getView().getModel();
                var oBindingContext = oModel.bindContext("/ManageODPPhase(...)");
                oBindingContext.setParameter("Record",
                    dataToSend
                );

                if (dataToSend.length > 0) {
                    oBindingContext.execute().then((oResult) => {
                        var oContext = oBindingContext.getBoundContext();
                        if (oContext.getObject().value.to_operations[0].flag_error === "true") {
                            oController.openDialogMessageText(oContext.getObject().value.to_operations[0].msg, "E");
                        } else {
                            oController.openDialogMessageText(oController.getResourceBundle().getText("operationCompletedSuccefully"), "S");
                        }
                        setTimeout(() => {
                            sap.ui.getCore().byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content-innerTable").getBinding("rows").refresh()
                        }, 1000);
                        sap.ui.getCore().byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations").getMDCTable().clearSelection()
                        oBusyDialog.close();

                    }).catch((oError) => {
                        oBusyDialog.close();
                        if (oError.error !== undefined && oError.error !== null) {
                            oController.openDialogMessageText(oError.error.message, "E");
                        } else {
                            oController.openDialogMessageText(oError, "E");
                        }
                    });
                } else {
                    //MessageToast.show(oController.getResourceBundle().getText("noDataToSend"))                     
                    oController.openDialogMessageText(oController.getResourceBundle().getText("noDataToSend"), "E");

                    oBusyDialog.close();
                }
                if (oController.buttonSelected === "addPhase") {
                    oController.pOperationsAddPhaseMasterDialog.close()
                } else if (oController.buttonSelected === "modifyPhase") {
                    oController.pOperationsAddPhaseMasterDialog.close()
                } else {
                    oController.pOperationsChangeWCMasterDialog.close()
                }
            },

            onDeleteOperationsMaster: function (oEvent) {
                console.log("onDeleteOperationsMaster");
                var dataToSend = []
                var dataObjectToSend = {}

                var table = this.byId("TableOperations").getSelectedContexts()

                for (var i = 0; i < table.length; i++) {
                    dataObjectToSend = {}
                    dataObjectToSend.id = "001"
                    dataObjectToSend.MasterProductionOrder = table[i].getObject().MasterProductionOrder
                    dataObjectToSend.ManufacturingOrderOperation = table[i].getObject().ManufacturingOrderOperation
                    dataObjectToSend.WorkCenter = table[i].getObject().WorkCenter
                    dataObjectToSend.Plant = table[i].getObject().Plant
                    dataObjectToSend.OperationControlProfile = table[i].getObject().OperationControlProfile
                    dataObjectToSend.MfgOrderOperationText = table[i].getObject().MfgOrderOperationText
                    dataObjectToSend.MaterialGroup = table[i].getObject().MaterialGroup
                    dataObjectToSend.ManufacturingOrderSequence = table[i].getObject().ManufacturingOrderSequence
                    dataObjectToSend.unit = ""//table[i].getObject().
                    dataObjectToSend.umson = table[i].FreeFlag
                    //dataObjectToSend.price = Number(table[i].OpExternalProcessingPrice) //table[i].getObject().           
                    dataObjectToSend.action = "DEL"
                    dataToSend.push(dataObjectToSend)
                }

                var oBusyDialog = new sap.m.BusyDialog();
                oBusyDialog.open();

                const oModel = oController.getView().getModel();
                var oBindingContext = oModel.bindContext("/ManageODPPhase(...)");
                oBindingContext.setParameter("Record",
                    dataToSend
                );

                if (dataToSend.length > 0) {
                    oBindingContext.execute().then((oResult) => {
                        var oContext = oBindingContext.getBoundContext();
                        if (oContext.getObject().value.to_operations[0].flag_error === "true") {
                            oController.openDialogMessageText(oContext.getObject().value.to_operations[0].msg, "E");
                        } else {
                            oController.openDialogMessageText(oController.getResourceBundle().getText("operationCompletedSuccefully"), "S");
                        }
                        setTimeout(() => {
                            sap.ui.getCore().byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations-content-innerTable").getBinding("rows").refresh()
                        }, 1000);
                        sap.ui.getCore().byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--TableOperations").getMDCTable().clearSelection()
                        oBusyDialog.close();

                    }).catch((oError) => {
                        oBusyDialog.close();
                        if (oError.error !== undefined && oError.error !== null) {
                            oController.openDialogMessageText(oError.error.message, "E");
                        } else {
                            oController.openDialogMessageText(oError, "E");
                        }
                    });
                } else {
                    //MessageToast.show(oController.getResourceBundle().getText("noDataToSend"))                     
                    oController.openDialogMessageText(oController.getResourceBundle().getText("noDataToSend"), "E");

                    oBusyDialog.close();
                }
            },

            openDialogMessageText: function (text, messType) {
                var vTitle = "Message";
                var vState = "Error";

                if (messType === "E") {
                    vTitle = this.getResourceBundle().getText("errorTitle");
                    vState = "Error";
                } else
                    if (messType === "S") {
                        vTitle = this.getResourceBundle().getText("successTitle");
                        vState = "Success";
                    }

                var dialog = new Dialog({
                    title: vTitle,
                    type: "Message",
                    state: vState,
                    content: new sap.m.Text({
                        text: text
                    }),

                    beginButton: new sap.m.Button({
                        text: "OK",
                        press: function () {
                            dialog.close();
                        }
                    }),
                    afterClose: function () {
                        dialog.destroy();
                    }
                });

                dialog.open();
            },

            onValueHelpRequestWorkCenters: function (oEvent) {
                //this.byId("shippingPointID").setValue();
                if (oController.pWorkCentersDialog === null || oController.pWorkCentersDialog === undefined) {
                    oController.pWorkCentersDialog = sap.ui.xmlfragment(this.getView().getId(), "productioncockpitapp.ext.Fragment.WorkCentersList",
                        oController);
                    oController.getView().addDependent(oController.pWorkCentersDialog);
                }

                var oInput = oEvent.getSource();
                oController._oWorkCenterContext = oInput.getBindingContext();

                // recupero indice della righe selezionata e poi filtro 
                var index = oEvent.getSource().getId().split("-")[oEvent.getSource().getId().split("-").length - 1]
                var oControl =
                    oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--OperationsChangeWCMasterTableId") ||
                    oController.byId("productioncockpitapp::ZZ1_C_MASTERORDER_OPEROperationsPage--OperationsAddPhaseMasterTableId");

                var currentPlant;

                if (oControl && oControl.getBinding("items")) {
                    var aContexts = oControl.getBinding("items").getContexts();

                    if (aContexts[index]) {
                        currentPlant = aContexts[index].getObject().Plant;
                    }
                }
                var aFilters = [new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, currentPlant)];
                //oController.byId("selectWorkCentersDialog").getBinding("items").filter(aFilters)

                var oList = oController.byId("selectWorkCentersDialog");
                var oBinding = oList.getBinding("items");
                oBinding.filter(aFilters);
                oBinding.refresh();
                oController.pWorkCentersDialog.open();
            },

            onValueHelpWorkCentersConfirm: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                oEvent.getSource().getBinding("items").filter([]);

                if (!oSelectedItem) {
                    return;
                }

                var oModel = oController._oWorkCenterContext.getModel();
                var sPath = oController._oWorkCenterContext.getPath();

                var sValue = oSelectedItem.getTitle ? oSelectedItem.getTitle() : oSelectedItem.getText();

                var sProfile =
                    sValue && sValue.startsWith("E") ? "PP02" :
                        sValue && sValue.startsWith("S") ? "PP01" : "";

                if (oModel && sPath) {
                    var oCurrentObject = oModel.getProperty(sPath);

                    if (oCurrentObject && Object.prototype.hasOwnProperty.call(oCurrentObject, "OperationControlProfile")) {
                        oModel.setProperty(sPath + "/OperationControlProfile", sProfile);
                    }
                }

                // Valori scelti nel SelectDialog
                var sWorkCenter = oSelectedItem.getTitle();
                var sWorkCenterText = oSelectedItem.getDescription();

                // Scrivo nel modello → la tabella si aggiorna da sola
                oModel.setProperty(sPath + "/WorkCenter", sWorkCenter);
                oModel.setProperty(sPath + "/WorkCenterInternalID_1_Text", sWorkCenterText);

            },

            /*  onValueHelpWorkCentersClose: function (oEvent) {
                 oController.pWorkCentersDialog.close();
             }, */

            onValueHelpWorkCentersSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new sap.ui.model.Filter("workcentertext", sap.ui.model.FilterOperator.Contains, sValue);

                oEvent.getSource().getBinding("items").filter([oFilter]);
            }

            /**
             * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
             * (NOT before the first rendering! onInit() is used for that one!).
             * @memberOf productioncockpitapp.ext.view.Operations
             */
            //  onBeforeRendering: function() {
            //
            //  },

            /**
             * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
             * This hook is the same one that SAPUI5 controls get after being rendered.
             * @memberOf productioncockpitapp.ext.view.Operations
             */
            //  onAfterRendering: function() {
            //
            //  },

            /**
             * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
             * @memberOf productioncockpitapp.ext.view.Operations
             */
            //  onExit: function() {
            //
            //  }
        });
    }
);
